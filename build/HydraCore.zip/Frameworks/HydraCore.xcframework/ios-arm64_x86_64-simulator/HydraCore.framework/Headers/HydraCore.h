//
//  HydraCore.h
//  HydraCore
//
//  Created by Pankaj Gaikar on 20/04/23.
//

#import <Foundation/Foundation.h>

//! Project version number for HydraCore.
FOUNDATION_EXPORT double HydraCoreVersionNumber;

//! Project version string for HydraCore.
FOUNDATION_EXPORT const unsigned char HydraCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HydraCore/PublicHeader.h>


