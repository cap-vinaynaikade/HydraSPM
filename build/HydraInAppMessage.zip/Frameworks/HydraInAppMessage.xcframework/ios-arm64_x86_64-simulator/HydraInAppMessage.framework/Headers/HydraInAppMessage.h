//
//  HydraInAppMessage.h
//  HydraInAppMessage
//
//  Created by Pankaj Gaikar on 20/04/23.
//

#import <Foundation/Foundation.h>

//! Project version number for HydraInAppMessage.
FOUNDATION_EXPORT double HydraInAppMessageVersionNumber;

//! Project version string for HydraInAppMessage.
FOUNDATION_EXPORT const unsigned char HydraInAppMessageVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HydraInAppMessage/PublicHeader.h>


