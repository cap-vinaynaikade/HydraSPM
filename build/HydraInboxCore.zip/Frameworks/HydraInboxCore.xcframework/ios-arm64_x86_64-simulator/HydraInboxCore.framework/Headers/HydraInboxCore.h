//
//  HydraInboxCore.h
//  HydraInboxCore
//

#import <Foundation/Foundation.h>

//! Project version number for HydraInboxCore.
FOUNDATION_EXPORT double HydraInboxCoreVersionNumber;

//! Project version string for HydraInboxCore.
FOUNDATION_EXPORT const unsigned char HydraInboxCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HydraInboxCore/PublicHeader.h>


